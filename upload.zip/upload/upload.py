#!/usr/bin/python3.8

''' Bibliotecas '''

import pandas as pd
import numpy as np
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk 


''' Carregar, parsear e normalizar  os dados em dataframes'''

df = pd.read_table('dados.txt')


''' Análise e transformaação de dados '''

dg = pd.DataFrame(df)
datatypes_per_column = {
       "Comprador": "string",
       "Descrição": "string",
       "Preço Unitário": "string",
       "Quantidade": "string",
       "Endereço": "string",
       "Fornecedor": "string"
       }


def parse_str(value):
    try:
        return str(value) if value not in [None, 'None', ''] else np.nan
    except:
        return np.nan


''' Validando dados do tipo String '''

for key, value in datatypes_per_column.items():
    if key in df.keys() and value == 'string':
        df[key] = df[key].apply(parse_str)	   

dh = dg.astype(datatypes_per_column)


'''Descartando dados que não estão presente '''

dh.dropna()

'''Conexão e inserção de dados no Elasticsearch'''

es = Elasticsearch(host='localhost', port='9200')
es.indices.create(index='dados', body={})
documents = dh.to_dict(orient='records')
bulk(es, documents, index='dados',doc_type='doc') 





